This package is for Fab of the AERO-VISTA Hrafn V1.4 on 6/29/2021.

Primary Technical Contact: Nicholas Belsten 321-537-9880 nbelsten@mit.edu
Secondary Contact: Frank Lind flind@mit.edu
Procurement: purchasing@haystack.mit.edu