This package is for quoting and Fab of the AERO-VISTA Hrafn V1.4 on 6/24/2021.

Primary Technical Contact: Nicholas Belsten 321-537-9880 nbelsten@mit.edu
Secondary Contact: Frank Lind flind@mit.edu
Procurement: purchasing@haystack.mit.edu